# Golpo Reveal — standalone app

A self-contained whiteboard/sketch-reveal video generator. Upload an image,
set a duration and a few style knobs, get back an MP4 of it being drawn in
stroke-by-stroke with paint trailing behind — no external services, no VLM
API key, nothing leaves your machine.

## Run it

```
pip install -r requirements.txt
python server.py
```

Requires `ffmpeg` on PATH (used for the final encode). Then open:

```
http://localhost:8420
```

## Files

- `engine.py`   — the actual reveal engine (segmentation, stroke tracing,
                  ink/fill scheduling, exact-duration render). No Flask
                  or HTTP code in here — you can also import and call
                  `render_golpo(...)` directly from a script.
- `server.py`   — Flask app: serves the UI and one endpoint,
                  `POST /api/render`, that takes an uploaded image + form
                  fields and streams back the rendered .mp4.
- `index.html`  — the UI. Single file, no build step, no framework.

## What the caller controls vs. what's automatic

You set:
- **duration_seconds** — the only timing number. Everything else adapts to
  hit this exactly.
- **direction** — tb / bt / lr / rl / clockwise / counter_clockwise. Governs
  both the order elements are drawn in and each element's own paint-fill
  sweep direction.
- **lead_frames** — how many frames the ink outline stays ahead of the
  colour fill trailing it.
- **ink_thickness**, **aspect_ratio**, **quality** (draft/standard/smooth —
  an internal motion-fluidity tier, not a literal fps you pick), plus a few
  advanced knobs (posterization colour count, minimum region size, ink/fill
  time split, cross-element overlap).

The engine decides on its own, per image:
- **How many elements** the picture breaks into (connected-component +
  convex-hull region segmentation, same logic as the original
  `segment_worker.py`).
- **How much time each element gets.** This stands in for the
  VLM-graded-complexity + deterministic-director step from the full
  pipeline (`vlm_worker.py` + `schedule_worker.py`): since there's no
  script/VLM call here, each element's own measured ink-stroke length and
  fill-region pixel count *is* the complexity signal, so a detailed element
  naturally gets proportionally more of the time budget than a single flat
  icon, entirely locally.
- **Frame count and fps.** You never set fps. Internally the engine
  renders every tick (no dropped frames -> no jumpiness) at a frame rate
  implied by the `quality` tier, then re-encodes at
  `fps = frames_written / duration_seconds` so the output duration is
  exact by construction, regardless of how simple or busy the image is.

## Extending toward the full pipeline

This app intentionally covers the image-only slice of the 5-worker system
you shared (`segment_worker.py` → `engine.compute_foreground` /
`extract_atomic_regions`, `golpo_reveal.py` + `06_golpo_production.py` →
`engine.py`'s ink/fill/scheduler/render code). It does **not** include
`align_worker.py` (audio word-timestamps) or the network calls inside
`vlm_worker.py` / `schedule_worker.py` (Gemini/Colab concept-grouping and
cue-anchored timing) — those need a script + audio + an API key, which
didn't fit "standalone, image in, video out, no keys". If you want script-
driven narration timing later, the natural seam is:
`build_elements_auto()` in `engine.py` — swap its region auto-grouping for
VLM-grouped `Concept`s, and feed real per-concept durations into
`Element.tick_budget` (already a supported override in `budget_elements()`)
instead of the local complexity weight.
