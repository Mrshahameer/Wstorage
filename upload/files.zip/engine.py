"""
engine.py
────────────────────────────────────────────────────────────────────────────
Standalone Golpo reveal engine. Merges (with no external job-store / pydantic
/ network dependencies):

  segment_worker.py  -> compute_foreground / extract_atomic_regions
  golpo_reveal.py     -> sketchify_preprocess / stroke tracing / ink+fill
                          tick generators
  golpo_production.py -> Element / measure / budget-solve / scheduler /
                          exact-duration render

PLUS two things the caller-facing app needs that none of the original
workers did standalone:

  1. A local "complexity" stand-in for the VLM+schedule-worker duration
     assignment. The real pipeline calls Gemini to grade each concept
     1..5 and a deterministic director converts that to seconds. Here,
     with no VLM/script available, each element's own measured ink+fill
     cost (strokes, regions, pixel counts) IS the complexity signal —
     elements that are naturally more detailed get proportionally more
     of the time budget, simple icons get proportionally less. This is
     computed automatically; nothing about it is exposed to the caller
     as "fps" or "ticks", only `duration_seconds` is a public knob.

  2. Automatic frame/fps budgeting: the caller supplies only
     `duration_seconds` (+ a quality tier). The engine picks a target
     frame RATE band internally, converts that into a raw sketch-tick
     budget for `render_production`, renders every tick (no dropped
     frames -> no jumpiness), then re-encodes at
     fps = frames_written / duration_seconds so duration is always
     exact by construction. fps is never a caller-facing input.
────────────────────────────────────────────────────────────────────────────
"""

import os
import subprocess
import tempfile
import uuid
import numpy as np
import cv2

try:
    from cv2 import ximgproc as _xip
    _HAS_XIP = True
except Exception:
    _HAS_XIP = False


# ═════════════════════════════════════════════════════════════════════════
# 0. SEGMENTATION  (from segment_worker.py, unchanged CV logic)
# ═════════════════════════════════════════════════════════════════════════
def compute_foreground(img: np.ndarray) -> np.ndarray:
    mask = (np.sum(img, axis=2) <= 705).astype(np.uint8) * 255
    mask[:5, :] = 0
    mask[-5:, :] = 0
    mask[:, :5] = 0
    mask[:, -5:] = 0
    return mask


def fill_shape_hull(mask: np.ndarray) -> np.ndarray:
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    filled = np.zeros_like(mask)
    if contours:
        all_pts = np.vstack(contours)
        hull = cv2.convexHull(all_pts)
        cv2.drawContours(filled, [hull], -1, 255, -1)
    return filled


def extract_atomic_regions(foreground_mask: np.ndarray, min_area: int = 80):
    h, w = foreground_mask.shape[:2]
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    closed = cv2.morphologyEx(foreground_mask, cv2.MORPH_CLOSE, kernel)
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(closed)

    raw_regions = []
    for i in range(1, num_labels):
        area = stats[i, cv2.CC_STAT_AREA]
        if area < min_area:
            continue
        mask = (labels == i).astype(np.uint8) * 255
        mask = cv2.bitwise_and(mask, foreground_mask)
        if np.sum(mask) == 0:
            continue
        x, y, cw, ch = stats[i, cv2.CC_STAT_LEFT], stats[i, cv2.CC_STAT_TOP], stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT]
        cx, cy = centroids[i]
        raw_regions.append({"mask": mask, "box": [x, y, x + cw, y + ch],
                             "centroid": [cx, cy], "area": int((mask > 0).sum()), "merged": False})

    raw_regions.sort(key=lambda r: r["area"], reverse=True)
    filled_masks = [fill_shape_hull(r["mask"]) for r in raw_regions]

    for i in range(len(raw_regions)):
        if raw_regions[i]["merged"]:
            continue
        filled_parent = filled_masks[i]
        for j in range(i + 1, len(raw_regions)):
            if raw_regions[j]["merged"]:
                continue
            child_mask = raw_regions[j]["mask"]
            overlap_mask = cv2.bitwise_and(child_mask, filled_parent)
            overlap_area = np.sum(overlap_mask > 0)
            child_area = np.sum(child_mask > 0)
            if child_area > 0 and (overlap_area / child_area) >= 0.85:
                raw_regions[i]["mask"] = cv2.bitwise_or(raw_regions[i]["mask"], raw_regions[j]["mask"])
                filled_masks[i] = cv2.bitwise_or(filled_masks[i], filled_masks[j])
                raw_regions[j]["merged"] = True

    active_regions = [r for r in raw_regions if not r["merged"]]
    for r in active_regions:
        contours, _ = cv2.findContours(r["mask"], cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            x, y, bw, bh = cv2.boundingRect(np.vstack(contours))
            r["box"] = [x, y, x + bw, y + bh]
            M = cv2.moments(r["mask"])
            if M["m00"] > 0:
                r["centroid"] = [M["m10"] / M["m00"], M["m01"] / M["m00"]]
            else:
                r["centroid"] = [x + bw / 2, y + bh / 2]
            r["area"] = int((r["mask"] > 0).sum())

    active_regions.sort(key=lambda r: (round(r["centroid"][1] / 40.0), r["centroid"][0]))
    regions = []
    for idx, r in enumerate(active_regions):
        bx = r["box"]
        regions.append({"id": idx, "mask": r["mask"],
                         "box_norm": [bx[0] / w, bx[1] / h, bx[2] / w, bx[3] / h],
                         "centroid_norm": [r["centroid"][0] / w, r["centroid"][1] / h],
                         "area": r["area"]})
    return regions


# ═════════════════════════════════════════════════════════════════════════
# 1. SKETCH-IFY + STROKE TRACING  (from golpo_reveal.py, unchanged)
# ═════════════════════════════════════════════════════════════════════════
def sketchify_preprocess(img_bgr, n_colors=10, white_bg=True):
    h, w = img_bgr.shape[:2]
    flat = cv2.bilateralFilter(img_bgr, d=9, sigmaColor=75, sigmaSpace=75)
    flat = cv2.bilateralFilter(flat, d=9, sigmaColor=75, sigmaSpace=75)

    lab = cv2.cvtColor(flat, cv2.COLOR_BGR2LAB).reshape(-1, 3).astype(np.float32)
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 12, 1.0)
    _, labels, centers = cv2.kmeans(lab, n_colors, None, crit, 4, cv2.KMEANS_PP_CENTERS)
    quant_lab = centers[labels.flatten()].reshape(h, w, 3).astype(np.uint8)
    flat = cv2.cvtColor(quant_lab, cv2.COLOR_LAB2BGR)

    gray = cv2.cvtColor(flat, cv2.COLOR_BGR2GRAY)
    gray_orig = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    ink = (gray_orig < 100).astype(np.uint8) * 255
    ink = _drop_small_components(ink, min_area=6)

    if white_bg:
        near_white = (gray > 245)
        flat[near_white] = (255, 255, 255)

    return flat, ink


def _drop_small_components(mask, min_area=5):
    n, lbl, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    out = np.zeros_like(mask)
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] >= min_area:
            out[lbl == i] = 255
    return out


def trace_ink_strokes(ink_mask, min_len=8):
    if _HAS_XIP:
        skel = _xip.thinning(ink_mask, thinningType=_xip.THINNING_ZHANGSUEN)
    else:
        skel = _skeleton_fallback(ink_mask)

    pts = set(map(tuple, np.argwhere(skel > 0)[:, ::-1]))
    strokes = []

    def neigh(p):
        x, y = p
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                if dx or dy:
                    q = (x + dx, y + dy)
                    if q in pts:
                        yield q

    def degree(p):
        return sum(1 for _ in neigh(p))

    endpoints = [p for p in pts if degree(p) == 1]
    seeds = endpoints + list(pts)

    for seed in seeds:
        if seed not in pts:
            continue
        path = [seed]
        pts.discard(seed)
        cur = seed
        while True:
            nxt = next((q for q in neigh(cur)), None)
            if nxt is None:
                break
            path.append(nxt)
            pts.discard(nxt)
            cur = nxt
        if len(path) >= min_len:
            strokes.append(np.array(path, dtype=np.int32))

    return _order_strokes_nearest(strokes)


def _order_strokes_nearest(strokes):
    if not strokes:
        return strokes
    M = len(strokes)
    starts = np.array([s[0] for s in strokes], dtype=np.float32)
    ends = np.array([s[-1] for s in strokes], dtype=np.float32)
    active = np.ones(M, dtype=bool)
    active[0] = False
    ordered = [strokes[0]]
    for _ in range(1, M):
        curr_end = ordered[-1][-1]
        d_starts = np.sum((starts - curr_end) ** 2, axis=1)
        d_ends = np.sum((ends - curr_end) ** 2, axis=1)
        d_starts[~active] = np.inf
        d_ends[~active] = np.inf
        idx_start = np.argmin(d_starts)
        idx_end = np.argmin(d_ends)
        if d_starts[idx_start] <= d_ends[idx_end]:
            j = idx_start
            s = strokes[j]
        else:
            j = idx_end
            s = strokes[j][::-1]
        active[j] = False
        ordered.append(s)
    return ordered


def _order_strokes_topdown(strokes):
    return sorted(strokes, key=lambda s: (int(s[:, 1].min()), int(s[:, 0].min())))


def _skeleton_fallback(mask):
    skel = np.zeros_like(mask)
    elem = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    work = mask.copy()
    while True:
        opened = cv2.morphologyEx(work, cv2.MORPH_OPEN, elem)
        temp = cv2.subtract(work, opened)
        eroded = cv2.erode(work, elem)
        skel = cv2.bitwise_or(skel, temp)
        work = eroded
        if cv2.countNonZero(work) == 0:
            break
    return skel


def ink_stroke_steps(canvas, outline_accum_mask, strokes, ink_color, thickness=3,
                      px_per_tick=14, real_ink=None, src=None):
    reveal = real_ink is not None and src is not None
    seg_mask = np.zeros(canvas.shape[:2], np.uint8) if reveal else None
    band = max(int(thickness), 3) + 2
    for stroke in strokes:
        i = 0
        n = len(stroke)
        while i < n:
            j = min(n, i + px_per_tick)
            seg = stroke[i:j]
            if seg_mask is not None:
                seg_mask[:] = 0
            for k in range(len(seg) - 1):
                p1 = tuple(int(v) for v in seg[k])
                p2 = tuple(int(v) for v in seg[k + 1])
                accum_color = (255, 255, 255) if len(outline_accum_mask.shape) == 3 else 255
                cv2.line(outline_accum_mask, p1, p2, accum_color, thickness)
                if reveal:
                    cv2.line(seg_mask, p1, p2, 255, band)
                else:
                    cv2.line(canvas, p1, p2, ink_color, thickness, cv2.LINE_AA)
            if reveal:
                m = (seg_mask > 0) & (real_ink > 0)
                canvas[m] = src[m]
            hx, hy = int(seg[-1][0]), int(seg[-1][1])
            i = j
            yield hx, hy


def _object_subregions(flat_bgr, object_mask, min_area=None):
    obj = object_mask > 0
    if not obj.any():
        return np.zeros(object_mask.shape, np.int32), []
    if min_area is None:
        min_area = 100

    region_id = np.zeros(obj.shape, np.int32)
    meta = []
    nid = 0
    for col in np.unique(flat_bgr[obj].reshape(-1, 3), axis=0):
        cmask = (obj & np.all(flat_bgr == col, axis=2)).astype(np.uint8)
        n, lbl, stats, cent = cv2.connectedComponentsWithStats(cmask, 8)
        for i in range(1, n):
            if stats[i, cv2.CC_STAT_AREA] < min_area:
                continue
            nid += 1
            region_id[lbl == i] = nid
            meta.append((nid, float(cent[i][1])))
        del cmask, lbl, stats, cent
    if nid == 0:
        region_id[obj] = 1
        meta = [(1, 0.0)]

    rid = region_id.astype(np.uint16)
    grown = np.empty_like(rid)
    k = np.ones((3, 3), np.uint8)
    for _ in range(50):
        un = obj & (rid == 0)
        if not un.any():
            break
        cv2.dilate(rid, k, dst=grown)
        mask_to_update = un & (grown > 0)
        rid[mask_to_update] = grown[mask_to_update]
        del mask_to_update

    un = obj & (rid == 0)
    if un.any():
        rid[un] = 1
    del grown, un

    region_id = rid.astype(np.int32)
    del rid
    region_id[~obj] = 0

    meta.sort(key=lambda x: x[1])
    return region_id, meta


# ═════════════════════════════════════════════════════════════════════════
# 2. ELEMENT + MEASURE + BUDGET-SOLVE  (from golpo_production.py)
# ═════════════════════════════════════════════════════════════════════════
BASELINE_PPT = 20
BASELINE_STEPS = 25
MIN_LEN = 14


class Element:
    def __init__(self, id, mask, mode='sketch', weight=1.0, tick_budget=None,
                 slide_from='left', slide_ticks=18, label=None):
        self.id = id
        self.mask = mask
        self.mode = mode
        self.weight = weight
        self.tick_budget = tick_budget
        self.slide_from = slide_from
        self.slide_ticks = slide_ticks
        self.label = label
        self.n_strokes = None
        self.n_regions = None
        self.measured_ink_ticks = None
        self.measured_fill_ticks = None
        self.solved_px_per_tick = None
        self.solved_fill_steps = None
        self.strokes = None
        self.region_id = None
        self.region_meta = None


def measure_element(el, flat_bgr, ink_mask):
    obj_ink = cv2.bitwise_and(ink_mask, ink_mask, mask=el.mask)
    strokes = _order_strokes_topdown(trace_ink_strokes(obj_ink, min_len=MIN_LEN))
    region_id, region_meta = _object_subregions(flat_bgr, el.mask)

    ink_ticks = sum(int(np.ceil(len(s) / BASELINE_PPT)) for s in strokes) if strokes else 0
    fill_ticks = 0
    for mid, _ in region_meta:
        total = int((region_id == mid).sum())
        chunk = max(1, total // BASELINE_STEPS)
        fill_ticks += int(np.ceil(total / chunk))

    el.strokes = strokes
    el.region_id = region_id
    el.region_meta = region_meta
    el.n_strokes = len(strokes)
    el.n_regions = len(region_meta)
    el.measured_ink_ticks = ink_ticks
    el.measured_fill_ticks = fill_ticks
    return ink_ticks, fill_ticks


def solve_px_per_tick(strokes, target_ticks):
    lengths = [len(s) for s in strokes]
    if not lengths:
        return BASELINE_PPT
    n_strokes = len(lengths)
    target_ticks = max(target_ticks, n_strokes)

    def ticks_at(ppt):
        return sum(-(-l // ppt) for l in lengths)

    lo, hi = 1, max(lengths)
    best = hi
    while lo <= hi:
        mid = (lo + hi) // 2
        t = ticks_at(mid)
        if t <= target_ticks:
            best = mid
            hi = mid - 1
        else:
            lo = mid + 1
    return best


def solve_fill_steps(n_regions, target_ticks):
    if n_regions == 0:
        return BASELINE_STEPS
    return max(1, round(target_ticks / n_regions))


def budget_elements(elements, total_sketch_tick_budget, ink_fraction=0.35):
    sketch_els = [e for e in elements if e.mode == 'sketch']
    explicit = [e for e in sketch_els if e.tick_budget is not None]
    implicit = [e for e in sketch_els if e.tick_budget is None]

    remaining_budget = total_sketch_tick_budget - sum(e.tick_budget for e in explicit)
    total_weight = sum(e.weight for e in implicit) or 1.0

    for e in explicit:
        _solve_one(e, e.tick_budget, ink_fraction)

    for e in implicit:
        share = remaining_budget * (e.weight / total_weight) if remaining_budget > 0 else e.measured_ink_ticks + e.measured_fill_ticks
        _solve_one(e, share, ink_fraction)

    return elements


def _solve_one(e, target_total_ticks, ink_fraction):
    target_ink = max(e.n_strokes, int(target_total_ticks * ink_fraction))
    target_fill = max(e.n_regions, int(target_total_ticks * (1 - ink_fraction)))
    e.solved_px_per_tick = solve_px_per_tick(e.strokes, target_ink)
    e.solved_fill_steps = solve_fill_steps(e.n_regions, target_fill)


# ═════════════════════════════════════════════════════════════════════════
# 3. LOCAL "COMPLEXITY" MODEL  — VLM/schedule-worker stand-in.
#    Real pipeline: Gemini grades each concept 1..5 -> deterministic
#    director converts to seconds. Here: each element's own measured
#    ink+fill ticks (already computed empirically in measure_element) ARE
#    the complexity signal, so more-detailed elements naturally get a
#    proportionally bigger slice of the time budget with zero network
#    calls. This is what feeds `Element.weight` before budgeting.
# ═════════════════════════════════════════════════════════════════════════
def assign_complexity_weights(elements):
    for e in elements:
        if e.mode != 'sketch':
            continue
        raw = (e.measured_ink_ticks or 0) + (e.measured_fill_ticks or 0)
        # sqrt-compress so one giant background region can't starve every
        # small icon down to near-zero draw time (mirrors the 1..5 discrete
        # complexity bucketing the VLM director used, but continuous)
        e.weight = max(1.0, raw) ** 0.5
    return elements


# ═════════════════════════════════════════════════════════════════════════
# 4. FILL / SLIDE-IN GENERATORS with full direction support
#    (tb / bt / lr / rl / clockwise / counter_clockwise)
# ═════════════════════════════════════════════════════════════════════════
def _sweep_order(ys, xs, direction):
    if direction == 'tb':
        return np.argsort(ys)
    if direction == 'bt':
        return np.argsort(-ys)
    if direction == 'lr':
        return np.argsort(xs)
    if direction == 'rl':
        return np.argsort(-xs)
    if direction in ('clockwise', 'ccw', 'counter_clockwise'):
        cy, cx = np.mean(ys), np.mean(xs)
        angles = np.arctan2(ys - cy, xs - cx)
        return np.argsort(angles) if direction == 'clockwise' else np.argsort(-angles)
    return np.arange(len(ys))


def region_fill_steps_budgeted(canvas, flat_bgr, object_mask, region_id, region_meta,
                                paint_src, sweep_direction='tb', steps=25):
    src = paint_src if paint_src is not None else flat_bgr
    for mid, _ in region_meta:
        rmask = region_id == mid
        ys, xs = np.where(rmask)
        if len(ys) == 0:
            continue
        idx = _sweep_order(ys, xs, sweep_direction)
        ys_sorted, xs_sorted = ys[idx], xs[idx]
        total = len(ys_sorted)
        chunk_size = max(1, total // steps)
        for i in range(0, total, chunk_size):
            sy = ys_sorted[i:i + chunk_size]
            sx = xs_sorted[i:i + chunk_size]
            canvas[sy, sx] = src[sy, sx]
            yield


def sketch_ticks(canvas, src, el, ink_mask, flat_bgr, ink_thickness=2, lead_frames=6,
                  sweep_direction='tb'):
    obj_ink = cv2.bitwise_and(ink_mask, ink_mask, mask=el.mask)
    outline_accum = np.zeros(canvas.shape[:2], np.uint8)
    ink_gen = ink_stroke_steps(canvas, outline_accum, el.strokes, (30, 30, 30),
                                thickness=ink_thickness, px_per_tick=el.solved_px_per_tick,
                                real_ink=obj_ink, src=src)
    color_gen = region_fill_steps_budgeted(canvas, flat_bgr, el.mask, el.region_id, el.region_meta,
                                            paint_src=src, sweep_direction=sweep_direction,
                                            steps=el.solved_fill_steps)

    ink_ticks = sum(int(np.ceil(len(s) / el.solved_px_per_tick)) for s in el.strokes) or 1
    fill_ticks = 0
    for mid, _ in el.region_meta:
        total = int((el.region_id == mid).sum())
        chunk = max(1, total // el.solved_fill_steps)
        fill_ticks += int(np.ceil(total / chunk))
    color_ratio = fill_ticks / float(max(1, ink_ticks))

    ink_done = color_done = False
    ink_count = color_count = 0
    while not (ink_done and color_done):
        if not ink_done:
            try:
                next(ink_gen); ink_count += 1
            except StopIteration:
                ink_done = True
        if not color_done and (ink_done or ink_count > lead_frames):
            if not ink_done:
                tgt = int((ink_count - lead_frames) * color_ratio)
                while color_count < tgt and not color_done:
                    try:
                        next(color_gen); color_count += 1
                    except StopIteration:
                        color_done = True
            else:
                try:
                    next(color_gen); color_count += 1
                except StopIteration:
                    color_done = True
        yield


def slide_in_ticks(canvas, src, el, h, w):
    ys, xs = np.where(el.mask > 0)
    if len(xs) == 0:
        return
    x1, y1, x2, y2 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
    sprite = src[y1:y2, x1:x2].copy()
    sprite_mask = el.mask[y1:y2, x1:x2]

    dx = dy = 0
    if el.slide_from == 'left':
        dx = -(x2) - 40
    elif el.slide_from == 'right':
        dx = (w - x1) + 40
    elif el.slide_from == 'top':
        dy = -(y2) - 40
    elif el.slide_from == 'bottom':
        dy = (h - y1) + 40

    n = max(1, el.slide_ticks)
    for i in range(n):
        t = (i + 1) / n
        ease = 1 - (1 - t) ** 3
        cx = x1 + int(dx * (1 - ease))
        cy = y1 + int(dy * (1 - ease))
        _stamp(canvas, sprite, sprite_mask, cx, cy, h, w)
        yield
    _stamp(canvas, sprite, sprite_mask, x1, y1, h, w)


def _stamp(canvas, sprite, sprite_mask, x, y, h, w):
    sh, sw = sprite.shape[:2]
    x0, y0 = max(0, x), max(0, y)
    x1c, y1c = min(w, x + sw), min(h, y + sh)
    if x1c <= x0 or y1c <= y0:
        return
    sx0, sy0 = x0 - x, y0 - y
    sx1, sy1 = sx0 + (x1c - x0), sy0 + (y1c - y0)
    region = canvas[y0:y1c, x0:x1c]
    m = sprite_mask[sy0:sy1, sx0:sx1] > 0
    region[m] = sprite[sy0:sy1, sx0:sx1][m]


# ═════════════════════════════════════════════════════════════════════════
# 5. SCHEDULER  (cross-element overlap)
# ═════════════════════════════════════════════════════════════════════════
def scheduled_ticks(canvas, src, elements, ink_mask, flat_bgr, h, w,
                     cross_element_lead=4, ink_thickness=2, lead_frames=6,
                     sweep_direction='tb'):
    def make_gen(el):
        if el.mode == 'sketch':
            return sketch_ticks(canvas, src, el, ink_mask, flat_bgr,
                                 ink_thickness=ink_thickness, lead_frames=lead_frames,
                                 sweep_direction=sweep_direction)
        else:
            return slide_in_ticks(canvas, src, el, h, w)

    def expected_len(el):
        if el.mode == 'sketch':
            ink_ticks = sum(int(np.ceil(len(s) / el.solved_px_per_tick)) for s in el.strokes) or 1
            fill_ticks = 0
            for mid, _ in el.region_meta:
                total = int((el.region_id == mid).sum())
                chunk = max(1, total // el.solved_fill_steps)
                fill_ticks += int(np.ceil(total / chunk))
            return ink_ticks + max(0, fill_ticks - int(ink_ticks * (fill_ticks / max(1, ink_ticks))))
        return el.slide_ticks

    n = len(elements)
    if n == 0:
        return
    active = [[make_gen(elements[0]), expected_len(elements[0])]]
    idx = 1

    while active:
        still_active = []
        for g in active:
            try:
                next(g[0])
                g[1] -= 1
                still_active.append(g)
            except StopIteration:
                pass
        active = still_active

        if idx < n:
            if not active or active[0][1] <= cross_element_lead:
                active.append([make_gen(elements[idx]), expected_len(elements[idx])])
                idx += 1
        yield


# ═════════════════════════════════════════════════════════════════════════
# 6. ASPECT RATIO  — letterbox onto white canvas (never crops content)
# ═════════════════════════════════════════════════════════════════════════
ASPECTS = {
    "original": None,
    "16:9": 16 / 9,
    "9:16": 9 / 16,
    "1:1": 1.0,
    "4:5": 4 / 5,
    "4:3": 4 / 3,
}


def apply_aspect_ratio(img_bgr, aspect_key):
    target = ASPECTS.get(aspect_key)
    if not target:
        return img_bgr
    h, w = img_bgr.shape[:2]
    cur = w / h
    if abs(cur - target) < 1e-3:
        return img_bgr
    if cur > target:
        # image wider than target -> grow height (pad top/bottom)
        new_h = int(round(w / target))
        pad = new_h - h
        top, bottom = pad // 2, pad - pad // 2
        out = cv2.copyMakeBorder(img_bgr, top, bottom, 0, 0, cv2.BORDER_CONSTANT, value=(255, 255, 255))
    else:
        # image taller than target -> grow width (pad left/right)
        new_w = int(round(h * target))
        pad = new_w - w
        left, right = pad // 2, pad - pad // 2
        out = cv2.copyMakeBorder(img_bgr, 0, 0, left, right, cv2.BORDER_CONSTANT, value=(255, 255, 255))
    return out


# ═════════════════════════════════════════════════════════════════════════
# 7. AUTO FRAME/FPS BUDGETING  — never exposed to the caller as "fps".
#    Caller gives duration_seconds (+ optional quality tier). We pick an
#    internal target frame-rate band, translate that into a raw sketch
#    tick budget, render every tick, then re-encode at
#    fps = frames_written / duration_seconds so duration is EXACT.
# ═════════════════════════════════════════════════════════════════════════
QUALITY_FPS = {
    "draft": 20,
    "standard": 30,
    "smooth": 45,
}


def auto_tick_budget(duration_seconds, hold_seconds, quality="standard"):
    target_fps = QUALITY_FPS.get(quality, 30)
    total_frames = max(30, int(round(duration_seconds * target_fps)))
    hold_frames = int(round(hold_seconds * target_fps))
    sketch_frames = max(10, total_frames - hold_frames)
    return sketch_frames, target_fps


# ═════════════════════════════════════════════════════════════════════════
# 8. TOP-LEVEL: build elements from an image (no VLM/script needed)
# ═════════════════════════════════════════════════════════════════════════
def build_elements_auto(img_bgr, min_region_area=80, direction='tb'):
    fg = compute_foreground(img_bgr)
    regions = extract_atomic_regions(fg, min_area=min_region_area)

    # order elements to match the chosen reveal direction so big-picture
    # composition follows the same flow as each element's own paint sweep
    def sort_key(r):
        cx, cy = r["centroid_norm"]
        if direction == 'tb':
            return (cy, cx)
        if direction == 'bt':
            return (-cy, cx)
        if direction == 'lr':
            return (cx, cy)
        if direction == 'rl':
            return (-cx, cy)
        if direction in ('clockwise', 'counter_clockwise', 'ccw'):
            import math
            ang = math.atan2(cy - 0.5, cx - 0.5)
            return ang if direction == 'clockwise' else -ang
        return (cy, cx)

    regions.sort(key=sort_key)
    elements = [Element(id=r["id"], mask=r["mask"], mode='sketch', weight=1.0) for r in regions]
    return elements


# ═════════════════════════════════════════════════════════════════════════
# 9. TOP-LEVEL RENDER  — exact duration, auto frame/fps budget, full
#    direction / lead-frame / aspect-ratio / thickness control.
# ═════════════════════════════════════════════════════════════════════════
def render_golpo(img_bgr, out_path, duration_seconds,
                  direction='tb', lead_frames=6, ink_thickness=2,
                  aspect_ratio='original', n_colors=14, min_region_area=80,
                  ink_fraction=0.35, cross_element_lead=4, hold_seconds=0.6,
                  quality='standard', max_output_width=1280, verbose=True):
    """
    direction        : 'tb' | 'bt' | 'lr' | 'rl' | 'clockwise' | 'counter_clockwise'
                        controls BOTH element draw order and each element's
                        own colour-sweep direction.
    lead_frames       : how many ink ticks the outline draws before colour
                        starts trailing behind it (frames of outline ahead
                        of colour reveal).
    duration_seconds  : the ONLY timing knob the caller sets. fps and raw
                        frame count are derived automatically.
    quality           : 'draft' | 'standard' | 'smooth' — internal target
                        frame-rate band, not exposed as literal fps.
    """
    norm_dir = {'top_to_bottom': 'tb', 'bottom_to_top': 'bt', 'left_to_right': 'lr',
                'right_to_left': 'rl', 'clockwise': 'clockwise',
                'counter_clockwise': 'counter_clockwise', 'ccw': 'counter_clockwise'}
    direction = norm_dir.get(direction, direction)

    img_bgr = apply_aspect_ratio(img_bgr, aspect_ratio)
    h, w = img_bgr.shape[:2]

    flat_bgr, ink_mask = sketchify_preprocess(img_bgr, n_colors=n_colors)

    elements = build_elements_auto(img_bgr, min_region_area=min_region_area, direction=direction)
    if not elements:
        raise ValueError("No drawable regions found in this image (it may be blank or near-white).")

    for el in elements:
        measure_element(el, flat_bgr, ink_mask)

    # complexity-aware weighting (VLM/schedule-worker stand-in)
    assign_complexity_weights(elements)

    # ---- AUTO frame/fps budget (duration_seconds is the only public knob) ----
    sketch_tick_budget, internal_fps = auto_tick_budget(duration_seconds, hold_seconds, quality)

    budget_elements(elements, sketch_tick_budget, ink_fraction=ink_fraction)

    if verbose:
        measured_ink = sum(e.measured_ink_ticks for e in elements)
        measured_fill = sum(e.measured_fill_ticks for e in elements)
        print(f"[engine] {len(elements)} elements | natural ticks ink={measured_ink} fill={measured_fill} "
              f"| auto sketch_tick_budget={sketch_tick_budget} (quality={quality})")

    # ---- RENDER every tick (no skipping) ----
    canvas = np.full((h, w, 3), 255, np.uint8)
    raw_path = out_path + f".{uuid.uuid4().hex[:8]}.raw.mp4"
    writer = cv2.VideoWriter(raw_path, cv2.VideoWriter_fourcc(*'mp4v'), internal_fps, (w, h))
    frames_written = 0

    for _ in scheduled_ticks(canvas, img_bgr, elements, ink_mask, flat_bgr, h, w,
                              cross_element_lead=cross_element_lead,
                              ink_thickness=ink_thickness, lead_frames=lead_frames,
                              sweep_direction=direction):
        writer.write(canvas)
        frames_written += 1

    for _ in range(int(internal_fps * hold_seconds)):
        writer.write(canvas)
        frames_written += 1
    writer.release()

    # ---- exact-duration re-encode ----
    final_fps = frames_written / float(duration_seconds)
    out_w = min(max_output_width, w)
    scale_expr = f"scale={out_w}:-2"
    try:
        subprocess.run(["ffmpeg", "-y", "-r", f"{final_fps:.4f}", "-i", raw_path,
                         "-vf", scale_expr,
                         "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20",
                         "-preset", "fast", out_path], check=True,
                        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    finally:
        if os.path.exists(raw_path):
            os.remove(raw_path)

    if verbose:
        print(f"[engine] raw_frames={frames_written} final_fps={final_fps:.2f} "
              f"-> duration={frames_written/final_fps:.3f}s (target {duration_seconds}s)")

    return {
        "frames_written": frames_written,
        "n_elements": len(elements),
        "duration_seconds": duration_seconds,
        "width": out_w,
    }
