"""
server.py
────────────────────────────────────────────────────────────────────────────
Standalone Golpo Reveal app. One process, one port.

  GET  /                 -> the UI (index.html)
  POST /api/render       -> multipart form: image=<file>, params as fields
                             returns the rendered .mp4 directly

Run:
    pip install -r requirements.txt
    python server.py
Then open http://localhost:8420
────────────────────────────────────────────────────────────────────────────
"""
import os
import uuid
import traceback
import numpy as np
import cv2
from flask import Flask, request, send_file, jsonify, send_from_directory

from engine import render_golpo, ASPECTS, QUALITY_FPS

APP_DIR = os.path.dirname(os.path.abspath(__file__))
WORK_DIR = os.path.join(APP_DIR, "_work")
os.makedirs(WORK_DIR, exist_ok=True)

app = Flask(__name__, static_folder=None)

MAX_UPLOAD_MB = 25
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024

VALID_DIRECTIONS = {"tb", "bt", "lr", "rl", "clockwise", "counter_clockwise"}


@app.route("/")
def index():
    return send_from_directory(APP_DIR, "index.html")


@app.route("/api/config")
def config():
    # exposes only caller-facing knobs — no fps here on purpose
    return jsonify({
        "aspect_ratios": list(ASPECTS.keys()),
        "directions": sorted(VALID_DIRECTIONS),
        "quality_tiers": list(QUALITY_FPS.keys()),
        "max_upload_mb": MAX_UPLOAD_MB,
    })


@app.route("/api/render", methods=["POST"])
def render():
    if "image" not in request.files:
        return jsonify({"error": "No image file uploaded (field name must be 'image')."}), 400

    f = request.files["image"]
    if not f.filename:
        return jsonify({"error": "Empty filename."}), 400

    job_id = uuid.uuid4().hex[:12]
    in_path = os.path.join(WORK_DIR, f"{job_id}_in")
    out_path = os.path.join(WORK_DIR, f"{job_id}_out.mp4")

    try:
        f.save(in_path)
        img = cv2.imread(in_path)
        if img is None:
            return jsonify({"error": "Could not decode image. Supported: PNG, JPG, WEBP, BMP."}), 400

        def ffloat(name, default, lo=None, hi=None):
            v = request.form.get(name, default)
            v = float(v)
            if lo is not None:
                v = max(lo, v)
            if hi is not None:
                v = min(hi, v)
            return v

        def fint(name, default, lo=None, hi=None):
            v = int(float(request.form.get(name, default)))
            if lo is not None:
                v = max(lo, v)
            if hi is not None:
                v = min(hi, v)
            return v

        duration_seconds = ffloat("duration_seconds", 6.0, lo=1.0, hi=60.0)
        direction = request.form.get("direction", "tb")
        if direction not in VALID_DIRECTIONS:
            return jsonify({"error": f"Invalid direction '{direction}'. Must be one of {sorted(VALID_DIRECTIONS)}"}), 400

        lead_frames = fint("lead_frames", 6, lo=0, hi=60)
        ink_thickness = fint("ink_thickness", 2, lo=1, hi=8)
        aspect_ratio = request.form.get("aspect_ratio", "original")
        if aspect_ratio not in ASPECTS:
            return jsonify({"error": f"Invalid aspect_ratio '{aspect_ratio}'. Must be one of {list(ASPECTS.keys())}"}), 400

        n_colors = fint("n_colors", 14, lo=2, hi=32)
        min_region_area = fint("min_region_area", 80, lo=10, hi=5000)
        ink_fraction = ffloat("ink_fraction", 0.35, lo=0.05, hi=0.9)
        cross_element_lead = fint("cross_element_lead", 4, lo=0, hi=60)
        hold_seconds = ffloat("hold_seconds", 0.6, lo=0.0, hi=5.0)
        quality = request.form.get("quality", "standard")
        if quality not in QUALITY_FPS:
            return jsonify({"error": f"Invalid quality '{quality}'. Must be one of {list(QUALITY_FPS.keys())}"}), 400

        result = render_golpo(
            img_bgr=img,
            out_path=out_path,
            duration_seconds=duration_seconds,
            direction=direction,
            lead_frames=lead_frames,
            ink_thickness=ink_thickness,
            aspect_ratio=aspect_ratio,
            n_colors=n_colors,
            min_region_area=min_region_area,
            ink_fraction=ink_fraction,
            cross_element_lead=cross_element_lead,
            hold_seconds=hold_seconds,
            quality=quality,
            verbose=True,
        )

        response = send_file(out_path, mimetype="video/mp4", as_attachment=False,
                              download_name="golpo_reveal.mp4")
        response.headers["X-Golpo-Elements"] = str(result["n_elements"])
        response.headers["X-Golpo-Frames"] = str(result["frames_written"])
        return response

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

    finally:
        for p in (in_path,):
            if os.path.exists(p):
                try:
                    os.remove(p)
                except OSError:
                    pass
        # out_path intentionally left until after send_file streams it;
        # OS temp-cleanup / a cron can sweep _work/ periodically in prod.


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8420, debug=False)
